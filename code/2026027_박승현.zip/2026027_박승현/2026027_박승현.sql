-- 2026학년도 1학기 데이터베이스 설계 및 구현 기말 프로젝트
-- 국내 관광 여행사 데이터베이스 구현
-- Student ID: 2026027
-- Student Name: 박승현


-- =========================================================
-- 0. 기존 객체 삭제
-- =========================================================
DROP TABLE IF EXISTS assign_bus, assign_driver, reserve, tour_bus, driver, tour, customer, staff, class_code, task_code CASCADE;

-- =========================================================
-- 1. CREATE TABLE
-- =========================================================

CREATE TABLE class_code (
    code NUMERIC(1) PRIMARY KEY,
    class VARCHAR(10) NOT NULL,
    basis VARCHAR(20)
);

CREATE TABLE task_code (
    code NUMERIC(1) PRIMARY KEY,
    task VARCHAR(30) NOT NULL
);

CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    cell CHAR(13) NOT NULL UNIQUE,
    addr VARCHAR(100),
    c_code NUMERIC(1) DEFAULT 3,
    CONSTRAINT customer_c_code_fk FOREIGN KEY (c_code)
        REFERENCES class_code(code)
);

CREATE TABLE staff (
    staff_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday NUMERIC(6) NOT NULL,
    tel CHAR(12),
    salary NUMERIC(9),
    t_code NUMERIC(1) NOT NULL,
    hire_date CHAR(8) NOT NULL,
    CONSTRAINT staff_t_code_fk FOREIGN KEY (t_code)
        REFERENCES task_code(code)
);

CREATE TABLE tour (
    tour_num CHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival VARCHAR(50) NOT NULL,
    program VARCHAR(100),
    start_dt DATE NOT NULL,
    end_dt DATE NOT NULL,
    min_num NUMERIC(2),
    max_num NUMERIC(2),
    expense NUMERIC(7) NOT NULL,
    deposit NUMERIC(6),
    dept_yn CHAR(1) DEFAULT 'N',
    staff_id NUMERIC(5),
    CONSTRAINT tour_staff_id_fk FOREIGN KEY (staff_id)
        REFERENCES staff(staff_id),
    CONSTRAINT tour_dept_yn_ck CHECK (dept_yn IN ('Y', 'N')),
    CONSTRAINT tour_date_ck CHECK (end_dt >= start_dt),
    CONSTRAINT tour_num_ck CHECK (min_num IS NULL OR max_num IS NULL OR min_num <= max_num)
);

CREATE TABLE driver (
    driver_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday CHAR(6) NOT NULL,
    cell CHAR(13) NOT NULL,
    pay NUMERIC(5) DEFAULT 15000,
    cont_date CHAR(8),
    cont_term CHAR(8)
);

CREATE TABLE tour_bus (
    bus_id NUMERIC(2) PRIMARY KEY,
    seat NUMERIC(2),
    del_year NUMERIC(4)
);

CREATE TABLE reserve (
    cus_id VARCHAR(15),
    tour_num CHAR(8),
    res_date CHAR(8) DEFAULT TO_CHAR(CURRENT_DATE, 'YYYYMMDD'),
    dep_yn CHAR(1) DEFAULT 'N',
    exp_yn CHAR(1) DEFAULT 'N',
    CONSTRAINT reserve_pk PRIMARY KEY (cus_id, tour_num),
    CONSTRAINT reserve_cus_id_fk FOREIGN KEY (cus_id)
        REFERENCES customer(cus_id),
    CONSTRAINT reserve_tour_num_fk FOREIGN KEY (tour_num)
        REFERENCES tour(tour_num),
    CONSTRAINT reserve_dep_yn_ck CHECK (dep_yn IN ('Y', 'N')),
    CONSTRAINT reserve_exp_yn_ck CHECK (exp_yn IN ('Y', 'N'))
);

CREATE TABLE assign_driver (
    tour_num CHAR(8) PRIMARY KEY,
    driver_id NUMERIC(5),
    work_hour NUMERIC(3),
    CONSTRAINT assign_driver_tour_num_fk FOREIGN KEY (tour_num)
        REFERENCES tour(tour_num),
    CONSTRAINT assign_driver_driver_id_fk FOREIGN KEY (driver_id)
        REFERENCES driver(driver_id)
);

CREATE TABLE assign_bus (
    tour_num CHAR(8) PRIMARY KEY,
    bus_id NUMERIC(2),
    CONSTRAINT assign_bus_tour_num_fk FOREIGN KEY (tour_num)
        REFERENCES tour(tour_num),
    CONSTRAINT assign_bus_bus_id_fk FOREIGN KEY (bus_id)
        REFERENCES tour_bus(bus_id)
);

-- =========================================================
-- 2. INSERT DATA
-- =========================================================

INSERT INTO class_code (code, class, basis) VALUES
(1, '최우수', '누적 이용 10회 이상'),
(2, '우수', '누적 이용 5회 이상'),
(3, '일반', '기본 고객 등급'),
(4, '신규', '첫 이용 고객'),
(5, '휴면', '장기 미이용 고객');

INSERT INTO task_code (code, task) VALUES
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) VALUES
(10001, '김민준', 850315, '02-1111-1111', 3200000, 1, '20210110'),
(10002, '이서연', 900722, '02-2222-2222', 3000000, 2, '20220315'),
(10003, '박지훈', 880905, '02-3333-3333', 3100000, 3, '20200420'),
(10004, '최유진', 920118, '02-4444-4444', 2900000, 4, '20230501'),
(10005, '정현우', 870611, '02-5555-5555', 3050000, 5, '20211201');

INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
('CUST001', '강하은', '010-1111-2222', '서울특별시 강남구', 1),
('CUST002', '김도윤', '010-2222-3333', '부산광역시 해운대구', 2),
('CUST003', '박서준', '010-3333-4444', '대구광역시 수성구', 3),
('CUST004', '이채원', '010-4444-5555', '대전광역시 서구', 2),
('CUST005', '최민서', '010-5555-6666', '광주광역시 북구', 3);

INSERT INTO tour (tour_num, departure, arrival, program, start_dt, end_dt, min_num, max_num, expense, deposit, dept_yn, staff_id) VALUES
('T2026001', '서울', '제주', 'https://tour.example.com/jeju', DATE '2026-07-01', DATE '2026-07-03', 10, 30, 450000, 100000, 'N', 10001),
('T2026002', '부산', '경주', 'https://tour.example.com/gyeongju', DATE '2026-07-05', DATE '2026-07-06', 8, 25, 250000, 50000, 'N', 10001),
('T2026003', '대전', '강릉', 'https://tour.example.com/gangneung', DATE '2026-07-10', DATE '2026-07-12', 12, 35, 380000, 80000, 'N', 10002),
('T2026004', '광주', '여수', 'https://tour.example.com/yeosu', DATE '2026-07-15', DATE '2026-07-16', 10, 30, 290000, 60000, 'N', 10002),
('T2026005', '인천', '속초', 'https://tour.example.com/sokcho', DATE '2026-07-20', DATE '2026-07-21', 9, 28, 270000, 50000, 'N', 10003);

INSERT INTO driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) VALUES
(20001, '한지민', '830105', '010-7777-1001', 18000, '20240101', '24'),
(20002, '오준호', '810922', '010-7777-1002', 17000, '20240201', '24'),
(20003, '윤서아', '890412', '010-7777-1003', 16000, '20240301', '12'),
(20004, '장도현', '850731', '010-7777-1004', 19000, '20240401', '36'),
(20005, '문지성', '900215', '010-7777-1005', 15000, '20240501', '12');

INSERT INTO tour_bus (bus_id, seat, del_year) VALUES
(1, 45, 2020),
(2, 35, 2021),
(3, 25, 2019),
(4, 40, 2022),
(5, 30, 2023);

INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
('CUST001', 'T2026001', '20260601', 'Y', 'N'),
('CUST002', 'T2026001', '20260602', 'Y', 'Y'),
('CUST003', 'T2026002', '20260603', 'N', 'N'),
('CUST004', 'T2026003', '20260604', 'Y', 'N'),
('CUST005', 'T2026005', '20260605', 'N', 'N');

INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
('T2026001', 20001, 20),
('T2026002', 20002, 12),
('T2026003', 20003, 22),
('T2026004', 20004, 10),
('T2026005', 20005, 14);

INSERT INTO assign_bus (tour_num, bus_id) VALUES
('T2026001', 1),
('T2026002', 2),
('T2026003', 3),
('T2026004', 4),
('T2026005', 5);

-- 초기 데이터 입력 확인
SELECT 'class_code' AS table_name, COUNT(*) AS row_count FROM class_code
UNION ALL SELECT 'task_code', COUNT(*) FROM task_code
UNION ALL SELECT 'customer', COUNT(*) FROM customer
UNION ALL SELECT 'staff', COUNT(*) FROM staff
UNION ALL SELECT 'tour', COUNT(*) FROM tour
UNION ALL SELECT 'reserve', COUNT(*) FROM reserve
UNION ALL SELECT 'driver', COUNT(*) FROM driver
UNION ALL SELECT 'tour_bus', COUNT(*) FROM tour_bus
UNION ALL SELECT 'assign_driver', COUNT(*) FROM assign_driver
UNION ALL SELECT 'assign_bus', COUNT(*) FROM assign_bus;

-- =========================================================
-- 3. CREATE INDEX
-- =========================================================

CREATE INDEX tour_arrival_idx ON tour(arrival ASC);
CREATE INDEX driver_name_idx ON driver(name ASC);

-- =========================================================
-- 4. TEST QUERIES
-- =========================================================

-- 4-1. 고객 등급 검색하기: 입력 id 예시 = 'CUST001'
SELECT c.cus_id,
       c.name AS customer_name,
       cc.class AS customer_class
FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'CUST001';

-- 4-2. 직원 담당업무 검색하기: 입력 사번 예시 = 10001
SELECT s.staff_id,
       s.name AS staff_name,
       tc.task AS task_name
FROM staff s
JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10001;

-- 4-3. 여행상품 예약 고객 검색하기: 입력 여행번호 예시 = 'T2026001'
SELECT r.tour_num,
       c.name AS customer_name,
       r.res_date,
       r.dep_yn AS deposit_paid
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = 'T2026001'
ORDER BY r.res_date ASC;

-- 4-4. 여행상품에 배정된 운전기사 검색하기: 입력 여행번호 예시 = 'T2026001'
SELECT t.tour_num,
       t.departure,
       d.name AS driver_name,
       d.cell AS driver_cell
FROM tour t
JOIN assign_driver ad ON t.tour_num = ad.tour_num
JOIN driver d ON ad.driver_id = d.driver_id
WHERE t.tour_num = 'T2026001';

-- 4-5. 고객 데이터 삽입하기
INSERT INTO customer (cus_id, name, cell, addr, c_code)
VALUES ('CUST006', '정하늘', '010-6666-7777', '충청북도 충주시', 3);

SELECT *
FROM customer
WHERE cus_id = 'CUST006';

-- 4-6. 직원 급여 변경하기: 입력 사번 예시 = 10001
SELECT staff_id, name, salary AS before_salary
FROM staff
WHERE staff_id = 10001;

UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 10001;

SELECT staff_id, name, salary AS after_salary
FROM staff
WHERE staff_id = 10001;

-- 4-7. 예약 정보 삭제하기: 입력 고객 id = 'CUST006', 입력 여행번호 = 'T2026005'
INSERT INTO reserve (cus_id, tour_num, dep_yn, exp_yn)
VALUES ('CUST006', 'T2026005', 'N', 'N');

SELECT *
FROM reserve
WHERE cus_id = 'CUST006' AND tour_num = 'T2026005';

DELETE FROM reserve
WHERE cus_id = 'CUST006' AND tour_num = 'T2026005';

SELECT *
FROM reserve
WHERE cus_id = 'CUST006' AND tour_num = 'T2026005';

-- 4-8. 인덱스 생성 확인
SELECT schemaname,
       tablename,
       indexname
FROM pg_indexes
WHERE schemaname = current_schema()
  AND indexname IN ('tour_arrival_idx', 'driver_name_idx');

-- =========================================================
-- 5. 전체 테이블 삭제 SQL
-- =========================================================
-- 아래 문장은 테이블 삭제 확인이 필요할 때 별도로 실행한다.
-- DROP TABLE IF EXISTS assign_bus, assign_driver, reserve, tour_bus, driver, tour, customer, staff, class_code, task_code CASCADE;
